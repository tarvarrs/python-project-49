#!/usr/bin/env python3
from brain_games.games.gcd import start


def main():
    start()


if __name__ == '__main__':
    main()
