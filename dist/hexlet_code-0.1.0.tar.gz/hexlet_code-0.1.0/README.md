### Hexlet tests and linter status:
[![Actions Status](https://github.com/tarvarrs/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tarvarrs/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f0648ad8f636d07e5ca3/maintainability)](https://codeclimate.com/github/tarvarrs/python-project-49/maintainability)

Brain Games is a Python project with five amazing minigames for your brain.

[![asciicast](https://asciinema.org/a/Hp8gDKAiB8vuuucpYMxD4CB6w.svg)](https://asciinema.org/a/Hp8gDKAiB8vuuucpYMxD4CB6w)
